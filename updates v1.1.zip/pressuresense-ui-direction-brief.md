# PressureSense — UI Direction Brief

The token system, dark mode, touch targets, and semantic color are already modern and correct. What's missing is **visual character** — right now it reads clean-but-generic (rounded cards, muted text, system font, vertical stack). "Modernize" here means *intentional and warm*, not flashy. Spend boldness in ONE place; keep everything else quiet.

**Hard constraint for this audience (older, in-pain, low-energy):** no glassmorphism, no heavy gradients-as-decoration, no animation for its own sake, no low-contrast trends. Calm and legible beats trendy. Every change below must preserve WCAG AA and the existing 18px/large-tap-target floor.

---

## Move 1 — Make the day the hero (highest impact)

Today the screen opens with a location bar and a text briefing. The thing people came for — *how will today feel* — should be the first and biggest thing the eye hits, expressed **visually, not as a paragraph.**

**Concept: "the horizon."** A single large hero element at the top that *is* the color of the day:
- A calm horizontal band/arc that fills with the day's band color (the teal/amber/red-orange already in tokens), with the big briefing headline over or beneath it.
- Think of it as a sky/horizon for the day — fitting for a weather-driven app — rather than a generic colored card.
- The band color carries meaning; pair it with the text label + icon (never color alone — the discipline already in `bandStyles.js`).
- Move the location bar to a slim, quiet row (it's navigation, not the headline) — small text + a pin, tappable to change. It should recede.

Wireframe (mobile):
```
┌─────────────────────────────┐
│  ⌖ Nags Head, NC        ☰   │  ← slim, quiet
├─────────────────────────────┤
│                             │
│      ╭───────────────╮      │  ← the horizon: filled with
│     (   today's color  )    │    today's band color, calm
│      ╰───────────────╯      │
│   Today looks GOOD ✓        │  ← headline, large display face
│   Stable, comfortable.      │
│                             │
├─────────────────────────────┤
│  tips · current · forecast  │  ← everything else, quiet
```

This spends the one bold move where it belongs and demotes the chrome.

---

## Move 2 — A real typeface (cheap, transformative)

The system-UI stack is invisible by design — fine for body, wrong for identity. Introduce **one characterful display face**, used with restraint, for exactly three things: the briefing headline, the big pressure number, and section heroes. Body text stays system-UI for maximum legibility.

- Pick a **warm, humanist** display face, not a cold geometric "tech" font — the audience and the caring tone call for something with a pulse. Candidates: *Fraunces* (soft optical serif, very warm), *Newsreader*, or a humanist sans like *Source Serif*/*Bricolage Grotesque* if you want sans. Avoid Inter-as-display (that's the generic default) and avoid anything thin.
- Load one weight or two; subset to keep it light on the PWA.
- The big pressure number is the natural place to let the display face be expressive — large, confident, tabular figures.

Keep body at weight 450+ as it is now; display can go heavier. Never go below 16px anywhere.

---

## Move 3 — Promote the hourly chart to a centerpiece

A pressure-pain app is fundamentally about *a curve over time*, and right now that curve is small and at the bottom. You already built the good parts (comfort-zone band, peak marker, band-colored dots, a11y label) in `HourlyChart.jsx` — give them room.

- Make it **larger and higher** in the layout — it's the second-most-important visual after the hero.
- Let the line itself carry band color along its length (segment the stroke by each hour's band) instead of only the dots — the *shape* should read as "heading into trouble" at a glance.
- Keep the comfort-zone shading; consider a subtle horizon echo so it rhymes with Move 1.
- Resist adding axes/gridlines clutter — the comfort band + peak label is enough; legibility over data-density for this audience.

---

## Move 4 — Quiet polish (do last, lightly)

- **Spacing rhythm:** establish one consistent vertical rhythm between cards (the stack is a touch uniform/flat). Group "Today" content tighter, then a clear gap before "Your tracking." Structure should encode the sections that already exist in `App.jsx`.
- **One accent, used sparingly:** the trust-blue `--accent` is fine; don't let band colors and accent compete. Bands = how the day feels; accent = interactive things (buttons, links). Keep that rule strict.
- **Reduce border-on-everything:** many cards are `border + rounded-2xl + bg-surface`. Consider letting some content sit directly on the background with spacing alone, reserving bordered cards for genuinely interactive panels. Fewer boxes = calmer.
- **Respect reduced-motion** if any transitions are added (the audience + the constraint demand it): wrap any motion in `@media (prefers-reduced-motion: no-preference)`.

---

## What to explicitly NOT do
- No glassmorphism / blur / translucent layering.
- No decorative gradients (a single band-color fill on the hero is meaning, not decoration — that's allowed).
- No animated counters, parallax, or load choreography.
- No dense dashboard styling — this is a calm daily check, not an analytics console.

---

## Suggested order
1. **Move 2 (typeface)** first — smallest change, instantly shifts "utility → product," and the hero in Move 1 will use it.
2. **Move 1 (hero/horizon)** — the signature moment.
3. **Move 3 (chart centerpiece)** — promotes the best asset you already built.
4. **Move 4 (polish)** — last, and lightly. Remember Chanel: take one thing off before shipping.
