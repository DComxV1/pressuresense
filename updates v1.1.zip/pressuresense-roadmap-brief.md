# PressureSense — Feature Roadmap Brief (v3)

The next features worth building, ordered by value-per-effort. Each notes what already exists in the code so the lift is clear.

---

## 1. Surface the correlation as a headline stat (your moat)
**Lift: small — the data is already stored.**

You already persist `minPressure` and the felt `type` per day (`storage.js`), and `CorrelationView` plots them. The missing piece is the *one sentence* that is the entire value proposition:

> "On low-pressure days, you've logged a rough day **3× as often** as on stable days."

- Compute it from history: split days into low-pressure vs. stable (e.g. below vs. above the comfort floor, or below the user's rolling median from Fix 3), then compare the rate of `type==='rough'` (and/or mean `pain`) between the two groups.
- Show it as a **big number + plain sentence** at the top of the correlation card, with a confidence note once N is small ("based on 14 logged days — keep logging to sharpen this").
- Gate it behind a minimum sample (e.g. 8–10 logged days) and a minimum of both groups present, mirroring the calibration readiness pattern in `calibrate.js`.

This is the single most compelling thing the app can say, proven with the user's own data. Make it the star.

---

## 2. Add migraine as a condition (doubles the audience)
**Lift: small-to-medium — reuses the whole pressure model.**

Barometric drops are one of the most-cited migraine triggers, and migraine sufferers are younger, more numerous, and far more app-inclined than the arthritis cohort — a large adjacent market for little new code.

- Add a `migraine` entry to `conditions.js` with its own tip set in `tips.js` (hydration, caffeine timing, dark/quiet, rescue-med timing, screen breaks — framed as "not medical advice").
- The risk model needs no change; pressure drops already drive the score. Optionally weight the **rate** factor a touch higher for migraine users, since rapid drops are the classic trigger.
- Add migraine-relevant log factors to the shared `FACTORS` list (or a condition-aware extension): "aura," "rescue med," "dark room," "caffeine." Keep the unified day-log shape.
- Education library: a short migraine + weather explainer.

---

## 3. Momentum / streak summary (retention hook)
**Lift: small — `goodStreak` already exists.**

Health apps retain users by showing momentum. You compute `goodStreak(history)` already; surface it.

- A compact "This month" card: good days logged, current good streak, and the user's top good-day factor (you already compute `goodFactors` in `DayLog.jsx`).
- Phrase as encouragement, never pressure: "12 good days logged this month — gentle movement shows up most." Tie into the existing `buildEncouragement` voice.
- Avoid streak-anxiety: don't punish broken streaks or use loss-framing. Celebrate, never scold.

---

## 4. Apple Health / wearable correlation (the long-term differentiator)
**Lift: large — mostly an iOS-port feature.**

The prize. Pull sleep and resting heart rate (HealthKit on the iOS port; Health Connect on Android) and move from "pressure vs. pain" to "pressure + poor sleep vs. pain." Poor sleep is often the bigger driver, so this is a genuinely differentiated product, not a nicer barometer.

- Data model already supports extra per-day fields — extend the day entry with optional `sleepHours`, `restingHR`.
- Extend the correlation engine to multi-factor: report which combination best predicts the user's rough days.
- Privacy first: all on-device, opt-in, nothing leaves the phone (matches the current local-only design and the export-as-backup model).
- Sequence this **after** the iOS port — HealthKit needs native.

---

## Suggested order
1. **Correlation headline (#1)** — small lift, proves the whole concept.
2. **Migraine (#2)** — small lift, big audience expansion.
3. **Momentum (#3)** — small lift, retention.
4. **Wearable correlation (#4)** — large lift, post-iOS, the durable moat.
