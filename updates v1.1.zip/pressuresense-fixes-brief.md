# PressureSense — Fixes & Hardening Brief

Three correctness/robustness issues found during code review. None are visible bugs today, but each can misfire for some users or under some conditions. Specified tightly so they can be applied directly.

---

## FIX 1 — Notification scheduling depends on an exact hour match (worker)

**File:** `worker/src/index.js` → `scheduledHandler`

**Problem.** The send slot is chosen by an exact equality:
```js
if (lh === (sub.morningHour ?? 7)) slot = 'morning'
else if (lh === (sub.eveningHour ?? 19)) slot = 'evening'
```
`lh` is the subscriber's current *local* hour. This only fires if the cron actually runs during the single hour that equals `morningHour`/`eveningHour`. If the cron cadence isn't hourly-on-the-hour, or a run is skipped/delayed, that subscriber gets nothing that day. It's brittle for a feature whose whole value is reliability.

**Fix.** Switch from "hour equals" to "we're at or past the target hour and haven't already sent today." The per-day dedup keys (`lastMorning`/`lastEvening`, already keyed to `targetDate`) make this safe — a late run still catches up, and a double run won't double-send.

```js
// Replace the exact-match slot selection with at-or-past + not-yet-sent-today.
const localDate = localDateKey(sub.tz || 'UTC', now) // 'YYYY-MM-DD' in sub's tz
const mh = sub.morningHour ?? 7
const eh = sub.eveningHour ?? 19

let slot = null
// Evening takes priority if both are due in the same run (rare, late cron).
if (lh >= eh && sub.lastEvening !== nextDayKey(localDate)) slot = 'evening'
else if (lh >= mh && lh < eh && sub.lastMorning !== localDate) slot = 'morning'
```

Notes:
- Evening's dedup compares against **tomorrow's** date key, because the evening push is a heads-up for tomorrow (`forecastForDay(..., 'evening')` targets `tomorrow`). Keep `lastEvening = f.targetDate` on send — that's already tomorrow's key, so this stays consistent.
- Morning's dedup compares against **today's** key.
- Add the small helpers next to `localHour`:
```js
function localDateKey(tz, date) {
  try {
    const p = new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit' }).format(date)
    return p // en-CA yields YYYY-MM-DD
  } catch { return date.toISOString().slice(0, 10) }
}
function nextDayKey(ymd) {
  const d = new Date(ymd + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + 1)
  return d.toISOString().slice(0, 10)
}
```
- **Also confirm `wrangler.toml` cron runs at least hourly** (e.g. `crons = ["0 * * * *"]`). The fix tolerates coarser/jittery schedules, but hourly is the right cadence so a user's chosen hour is honored within ~an hour.

**Acceptance check.** Set morningHour to the current local hour, force-run the scheduled handler twice — exactly one morning push on a non-green day, zero on the second run (deduped). Set it to an hour already passed earlier today with no prior send — it still fires once.

---

## FIX 2 — Geocoding network calls can hang (no timeout)

**File:** `src/lib/weather.js` → `geocode`, `reverseGeocode`

**Problem.** `fetchPressureSeries` is wrapped in App-level cancellation, but the two geocoding calls have no timeout. A slow/stalled BigDataCloud or Open-Meteo geocoding response leaves the location flow spinning (`locating` stays true) with no feedback.

**Fix.** Add a small `AbortController` timeout helper and use it for all three fetches.

```js
async function fetchWithTimeout(url, ms = 8000) {
  const ctrl = new AbortController()
  const t = setTimeout(() => ctrl.abort(), ms)
  try {
    return await fetch(url, { signal: ctrl.signal })
  } finally {
    clearTimeout(t)
  }
}
```
- `geocode`: use `fetchWithTimeout`; on abort/error, surface a friendly "Couldn't search locations, check your connection" rather than throwing raw.
- `reverseGeocode`: already has a try/catch that falls back to coordinates — route its fetch through `fetchWithTimeout` so a stall falls back to coords quickly instead of hanging.
- In `App.jsx` `useDeviceLocation`, ensure `setLocating(false)` runs in all paths (it does today on success/error, but confirm the reverseGeocode stall now resolves fast via the timeout).

**Acceptance check.** Throttle network to offline mid-search → the UI shows an error/falls back within ~8s instead of spinning indefinitely.

---

## FIX 3 — Absolute-pressure scoring uses sea-level pressure for users at elevation

**Files:** `src/lib/weather.js` (fetch), `src/lib/risk.js` (scoring), `worker/src/index.js` (mirror)

**Problem.** Scoring reads `pressure_msl` (sea-level-adjusted). MSL deliberately removes the altitude effect, so two cities at different elevations with identical "real" pressure report nearly the same MSL. The body, though, feels **station/surface pressure**. At elevation (e.g. Denver ~840 hPa surface) the `absoluteFactor` — whose comfort zone is 1013–1023 hPa — will read permanently "low/severe," pinning those users yellow/red regardless of weather. The **rate** factor is unaffected (the *change* is what matters and both series move together), so this only distorts the absolute component.

The fetch already pulls `surface_pressure` — it's just unused.

**Fix (recommended: rate-anchored absolute, elevation-proof).** Rather than picking MSL vs. surface, make the absolute factor relative to a local baseline so it works at any elevation:
- Compute a rolling baseline = median of the trailing ~72h of the chosen pressure series.
- `absoluteFactor` measures how far *below the user's own normal* the current reading is, not distance from a fixed 1013 hPa.
- This keeps the comfort-zone concept but recenters it per location, fixing Denver without breaking sea-level users.

If that's too big a change for now, **minimum viable fix:**
- Add a `pressureField: 'msl' | 'surface'` config (default `'msl'`), thread it through `computeHourlyRisk`, and expose surface as an option. Document that absolute scoring assumes near-sea-level when using MSL.
- At minimum, add a code comment at the `absoluteFactor` call site noting the elevation caveat so it isn't silently wrong.

Keep the worker's compact model in sync with whichever approach is chosen (it currently hardcodes the same MSL thresholds).

**Acceptance check.** Feed a Denver coordinate → today's band should track weather changes (rate-driven) instead of being stuck red from the altitude offset.

---

## Suggested order
1. **FIX 1** (reliability of the core notification promise) — highest user impact.
2. **FIX 2** (cheap, removes a silent hang).
3. **FIX 3** — do the MVP comment/option now; schedule the rate-anchored baseline as a small follow-up since it also improves the model generally.
